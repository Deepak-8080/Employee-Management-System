package com.ems.service;

import com.ems.dto.PagedResponse;
import com.ems.dto.SalaryRequest;
import com.ems.dto.SalaryResponse;

public interface SalaryService {
    SalaryResponse create(SalaryRequest request);
    SalaryResponse update(Long id, SalaryRequest request);
    SalaryResponse get(Long id);
    PagedResponse<SalaryResponse> list(int page, int size, String sortBy, String direction, Long employeeId);
    void delete(Long id);
}
