package com.ems.service.impl;

import com.ems.dto.EmployeeRequest;
import com.ems.dto.EmployeeResponse;
import com.ems.dto.PagedResponse;
import com.ems.entity.Department;
import com.ems.entity.Employee;
import com.ems.entity.User;
import com.ems.enums.EmploymentStatus;
import com.ems.exception.BadRequestException;
import com.ems.exception.ResourceNotFoundException;
import com.ems.mapper.EmployeeMapper;
import com.ems.repository.DepartmentRepository;
import com.ems.repository.EmployeeRepository;
import com.ems.repository.UserRepository;
import com.ems.service.EmployeeService;
import com.ems.util.FileStorageUtil;
import com.ems.util.PageUtil;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.multipart.MultipartFile;

@Service
@Transactional
public class EmployeeServiceImpl implements EmployeeService {
    private final EmployeeRepository repository;
    private final DepartmentRepository departmentRepository;
    private final UserRepository userRepository;
    private final EmployeeMapper mapper;
    private final FileStorageUtil fileStorageUtil;

    public EmployeeServiceImpl(EmployeeRepository repository, DepartmentRepository departmentRepository, UserRepository userRepository, EmployeeMapper mapper, FileStorageUtil fileStorageUtil) {
        this.repository = repository;
        this.departmentRepository = departmentRepository;
        this.userRepository = userRepository;
        this.mapper = mapper;
        this.fileStorageUtil = fileStorageUtil;
    }

    public EmployeeResponse create(EmployeeRequest request) {
        if (repository.existsByEmployeeCodeAndDeletedFalse(request.employeeCode())) {
            throw new BadRequestException("Employee code already exists");
        }
        if (repository.existsByEmailAndDeletedFalse(request.email())) {
            throw new BadRequestException("Employee email already exists");
        }
        return mapper.toResponse(repository.save(mapper.toEntity(request, department(request.departmentId()), user(request.userId()))));
    }

    public EmployeeResponse update(Long id, EmployeeRequest request) {
        Employee employee = active(id);
        mapper.update(employee, request, department(request.departmentId()), user(request.userId()));
        return mapper.toResponse(employee);
    }

    @Transactional(readOnly = true)
    public EmployeeResponse get(Long id) {
        return mapper.toResponse(active(id));
    }

    @Transactional(readOnly = true)
    public PagedResponse<EmployeeResponse> list(int page, int size, String sortBy, String direction, Long departmentId, EmploymentStatus status) {
        var pageable = PageUtil.pageable(page, size, sortBy, direction);
        var result = departmentId != null ? repository.findByDeletedFalseAndDepartmentId(departmentId, pageable) : status != null ? repository.findByDeletedFalseAndStatus(status, pageable) : repository.findByDeletedFalse(pageable);
        return PagedResponse.from(result.map(mapper::toResponse));
    }

    @Transactional(readOnly = true)
    public PagedResponse<EmployeeResponse> search(String keyword, int page, int size, String sortBy, String direction) {
        String value = keyword == null ? "" : keyword;
        return PagedResponse.from(repository.findByDeletedFalseAndFirstNameContainingIgnoreCaseOrDeletedFalseAndLastNameContainingIgnoreCaseOrDeletedFalseAndEmailContainingIgnoreCase(value, value, value, PageUtil.pageable(page, size, sortBy, direction)).map(mapper::toResponse));
    }

    public EmployeeResponse uploadProfileImage(Long id, MultipartFile file) {
        Employee employee = active(id);
        employee.setProfileImagePath(fileStorageUtil.saveProfileImage(file));
        return mapper.toResponse(employee);
    }

    public void delete(Long id) {
        active(id).setDeleted(true);
    }

    private Employee active(Long id) {
        Employee employee = repository.findById(id).orElseThrow(() -> new ResourceNotFoundException("Employee not found"));
        if (employee.isDeleted()) {
            throw new ResourceNotFoundException("Employee not found");
        }
        return employee;
    }

    private Department department(Long id) {
        Department department = departmentRepository.findById(id).orElseThrow(() -> new ResourceNotFoundException("Department not found"));
        if (department.isDeleted()) {
            throw new ResourceNotFoundException("Department not found");
        }
        return department;
    }

    private User user(Long id) {
        return id == null ? null : userRepository.findById(id).orElseThrow(() -> new ResourceNotFoundException("User not found"));
    }
}
