package com.ems.service.impl;

import com.ems.dto.AttendanceRequest;
import com.ems.dto.AttendanceResponse;
import com.ems.dto.PagedResponse;
import com.ems.entity.Attendance;
import com.ems.entity.Employee;
import com.ems.exception.ResourceNotFoundException;
import com.ems.mapper.AttendanceMapper;
import com.ems.repository.AttendanceRepository;
import com.ems.repository.EmployeeRepository;
import com.ems.service.AttendanceService;
import com.ems.util.PageUtil;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Service
@Transactional
public class AttendanceServiceImpl implements AttendanceService {
    private final AttendanceRepository repository;
    private final EmployeeRepository employeeRepository;
    private final AttendanceMapper mapper;

    public AttendanceServiceImpl(AttendanceRepository repository, EmployeeRepository employeeRepository, AttendanceMapper mapper) {
        this.repository = repository;
        this.employeeRepository = employeeRepository;
        this.mapper = mapper;
    }

    public AttendanceResponse create(AttendanceRequest request) {
        return mapper.toResponse(repository.save(mapper.toEntity(request, employee(request.employeeId()))));
    }

    public AttendanceResponse update(Long id, AttendanceRequest request) {
        Attendance attendance = active(id);
        mapper.update(attendance, request, employee(request.employeeId()));
        return mapper.toResponse(attendance);
    }

    @Transactional(readOnly = true)
    public AttendanceResponse get(Long id) {
        return mapper.toResponse(active(id));
    }

    @Transactional(readOnly = true)
    public PagedResponse<AttendanceResponse> list(int page, int size, String sortBy, String direction, Long employeeId) {
        var pageable = PageUtil.pageable(page, size, sortBy, direction);
        var result = employeeId == null ? repository.findByDeletedFalse(pageable) : repository.findByDeletedFalseAndEmployeeId(employeeId, pageable);
        return PagedResponse.from(result.map(mapper::toResponse));
    }

    public void delete(Long id) {
        active(id).setDeleted(true);
    }

    private Attendance active(Long id) {
        Attendance attendance = repository.findById(id).orElseThrow(() -> new ResourceNotFoundException("Attendance not found"));
        if (attendance.isDeleted()) {
            throw new ResourceNotFoundException("Attendance not found");
        }
        return attendance;
    }

    private Employee employee(Long id) {
        Employee employee = employeeRepository.findById(id).orElseThrow(() -> new ResourceNotFoundException("Employee not found"));
        if (employee.isDeleted()) {
            throw new ResourceNotFoundException("Employee not found");
        }
        return employee;
    }
}
