package com.ems.service.impl;

import com.ems.dto.*;
import com.ems.entity.RefreshToken;
import com.ems.entity.Role;
import com.ems.entity.User;
import com.ems.enums.RoleName;
import com.ems.exception.BadRequestException;
import com.ems.exception.ResourceNotFoundException;
import com.ems.repository.RefreshTokenRepository;
import com.ems.repository.RoleRepository;
import com.ems.repository.UserRepository;
import com.ems.security.JwtService;
import com.ems.security.UserPrincipal;
import com.ems.service.AuthService;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.Instant;
import java.util.Set;
import java.util.UUID;
import java.util.stream.Collectors;

@Service
@Transactional
public class AuthServiceImpl implements AuthService {
    private final AuthenticationManager authenticationManager;
    private final UserRepository userRepository;
    private final RoleRepository roleRepository;
    private final RefreshTokenRepository refreshTokenRepository;
    private final PasswordEncoder passwordEncoder;
    private final JwtService jwtService;
    private final long refreshExpirationMs;

    public AuthServiceImpl(AuthenticationManager authenticationManager, UserRepository userRepository, RoleRepository roleRepository, RefreshTokenRepository refreshTokenRepository, PasswordEncoder passwordEncoder, JwtService jwtService, @Value("${app.jwt.refresh-expiration-ms}") long refreshExpirationMs) {
        this.authenticationManager = authenticationManager;
        this.userRepository = userRepository;
        this.roleRepository = roleRepository;
        this.refreshTokenRepository = refreshTokenRepository;
        this.passwordEncoder = passwordEncoder;
        this.jwtService = jwtService;
        this.refreshExpirationMs = refreshExpirationMs;
    }

    @Override
    public AuthResponse login(AuthRequest request) {
        authenticationManager.authenticate(new UsernamePasswordAuthenticationToken(request.usernameOrEmail(), request.password()));
        User user = userRepository.findByUsernameOrEmail(request.usernameOrEmail(), request.usernameOrEmail()).orElseThrow(() -> new ResourceNotFoundException("User not found"));
        return authResponse(user);
    }

    @Override
    public AuthResponse register(RegisterRequest request) {
        if (userRepository.existsByUsername(request.username())) {
            throw new BadRequestException("Username already exists");
        }
        if (userRepository.existsByEmail(request.email())) {
            throw new BadRequestException("Email already exists");
        }
        Set<String> roleNames = request.roles() == null || request.roles().isEmpty() ? Set.of("ROLE_EMPLOYEE") : request.roles();
        Set<Role> roles = roleNames.stream().map(this::role).collect(Collectors.toSet());
        User user = User.builder().username(request.username()).email(request.email()).password(passwordEncoder.encode(request.password())).enabled(true).roles(roles).build();
        return authResponse(userRepository.save(user));
    }

    @Override
    public AuthResponse refresh(RefreshTokenRequest request) {
        RefreshToken refreshToken = refreshTokenRepository.findByToken(request.refreshToken()).orElseThrow(() -> new BadRequestException("Invalid refresh token"));
        if (refreshToken.getExpiresAt().isBefore(Instant.now())) {
            refreshTokenRepository.delete(refreshToken);
            throw new BadRequestException("Refresh token expired");
        }
        return authResponse(refreshToken.getUser());
    }

    @Override
    public void changePassword(String username, PasswordChangeRequest request) {
        User user = userRepository.findByUsernameOrEmail(username, username).orElseThrow(() -> new ResourceNotFoundException("User not found"));
        if (!passwordEncoder.matches(request.currentPassword(), user.getPassword())) {
            throw new BadRequestException("Current password is incorrect");
        }
        user.setPassword(passwordEncoder.encode(request.newPassword()));
    }

    @Override
    public String forgotPassword(ForgotPasswordRequest request) {
        User user = userRepository.findByEmail(request.email()).orElseThrow(() -> new ResourceNotFoundException("User not found"));
        String token = UUID.randomUUID().toString();
        user.setPasswordResetToken(token);
        return token;
    }

    @Override
    public void resetPassword(ResetPasswordRequest request) {
        User user = userRepository.findByPasswordResetToken(request.token()).orElseThrow(() -> new BadRequestException("Invalid reset token"));
        user.setPassword(passwordEncoder.encode(request.newPassword()));
        user.setPasswordResetToken(null);
    }

    private AuthResponse authResponse(User user) {
        refreshTokenRepository.deleteByUser(user);
        refreshTokenRepository.flush();
        RefreshToken refreshToken = RefreshToken.builder().token(UUID.randomUUID().toString()).user(user).expiresAt(Instant.now().plusMillis(refreshExpirationMs)).build();
        refreshTokenRepository.save(refreshToken);
        UserPrincipal principal = new UserPrincipal(user);
        Set<String> roles = user.getRoles().stream().map(role -> role.getName().name()).collect(Collectors.toSet());
        return new AuthResponse(jwtService.generateToken(principal), refreshToken.getToken(), "Bearer", user.getId(), user.getUsername(), user.getEmail(), roles);
    }

    private Role role(String name) {
        RoleName roleName = RoleName.valueOf(name.startsWith("ROLE_") ? name : "ROLE_" + name);
        return roleRepository.findByName(roleName).orElseThrow(() -> new BadRequestException("Role not found: " + roleName));
    }
}
