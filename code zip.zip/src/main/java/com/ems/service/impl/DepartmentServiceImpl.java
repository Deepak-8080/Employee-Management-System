package com.ems.service.impl;

import com.ems.dto.DepartmentRequest;
import com.ems.dto.DepartmentResponse;
import com.ems.dto.PagedResponse;
import com.ems.entity.Department;
import com.ems.exception.BadRequestException;
import com.ems.exception.ResourceNotFoundException;
import com.ems.mapper.DepartmentMapper;
import com.ems.repository.DepartmentRepository;
import com.ems.service.DepartmentService;
import com.ems.util.PageUtil;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Service
@Transactional
public class DepartmentServiceImpl implements DepartmentService {
    private final DepartmentRepository repository;
    private final DepartmentMapper mapper;

    public DepartmentServiceImpl(DepartmentRepository repository, DepartmentMapper mapper) {
        this.repository = repository;
        this.mapper = mapper;
    }

    public DepartmentResponse create(DepartmentRequest request) {
        if (repository.existsByNameIgnoreCaseAndDeletedFalse(request.name())) {
            throw new BadRequestException("Department already exists");
        }
        return mapper.toResponse(repository.save(mapper.toEntity(request)));
    }

    public DepartmentResponse update(Long id, DepartmentRequest request) {
        Department department = active(id);
        mapper.update(department, request);
        return mapper.toResponse(department);
    }

    @Transactional(readOnly = true)
    public DepartmentResponse get(Long id) {
        return mapper.toResponse(active(id));
    }

    @Transactional(readOnly = true)
    public PagedResponse<DepartmentResponse> list(int page, int size, String sortBy, String direction) {
        return PagedResponse.from(repository.findByDeletedFalse(PageUtil.pageable(page, size, sortBy, direction)).map(mapper::toResponse));
    }

    public void delete(Long id) {
        Department department = active(id);
        department.setDeleted(true);
    }

    private Department active(Long id) {
        Department department = repository.findById(id).orElseThrow(() -> new ResourceNotFoundException("Department not found"));
        if (department.isDeleted()) {
            throw new ResourceNotFoundException("Department not found");
        }
        return department;
    }
}
