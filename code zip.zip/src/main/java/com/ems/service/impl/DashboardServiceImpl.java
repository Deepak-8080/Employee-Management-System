package com.ems.service.impl;

import com.ems.dto.DashboardResponse;
import com.ems.enums.LeaveStatus;
import com.ems.enums.SalaryStatus;
import com.ems.repository.*;
import com.ems.service.DashboardService;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDate;

@Service
@Transactional(readOnly = true)
public class DashboardServiceImpl implements DashboardService {
    private final EmployeeRepository employeeRepository;
    private final DepartmentRepository departmentRepository;
    private final LeaveRequestRepository leaveRequestRepository;
    private final AttendanceRepository attendanceRepository;
    private final SalaryRepository salaryRepository;

    public DashboardServiceImpl(EmployeeRepository employeeRepository, DepartmentRepository departmentRepository, LeaveRequestRepository leaveRequestRepository, AttendanceRepository attendanceRepository, SalaryRepository salaryRepository) {
        this.employeeRepository = employeeRepository;
        this.departmentRepository = departmentRepository;
        this.leaveRequestRepository = leaveRequestRepository;
        this.attendanceRepository = attendanceRepository;
        this.salaryRepository = salaryRepository;
    }

    public DashboardResponse dashboard() {
        return new DashboardResponse(employeeRepository.findByDeletedFalse(org.springframework.data.domain.Pageable.unpaged()).getTotalElements(), departmentRepository.findByDeletedFalse(org.springframework.data.domain.Pageable.unpaged()).getTotalElements(), leaveRequestRepository.countByDeletedFalseAndStatus(LeaveStatus.PENDING), attendanceRepository.countByDeletedFalseAndAttendanceDate(LocalDate.now()), salaryRepository.countByDeletedFalseAndStatus(SalaryStatus.PAID));
    }
}
