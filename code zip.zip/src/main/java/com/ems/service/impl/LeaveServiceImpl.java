package com.ems.service.impl;

import com.ems.dto.LeaveApprovalRequest;
import com.ems.dto.LeaveRequestDto;
import com.ems.dto.LeaveResponse;
import com.ems.dto.PagedResponse;
import com.ems.entity.Employee;
import com.ems.entity.LeaveRequest;
import com.ems.enums.LeaveStatus;
import com.ems.exception.BadRequestException;
import com.ems.exception.ResourceNotFoundException;
import com.ems.mapper.LeaveMapper;
import com.ems.repository.EmployeeRepository;
import com.ems.repository.LeaveRequestRepository;
import com.ems.service.LeaveService;
import com.ems.util.PageUtil;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Service
@Transactional
public class LeaveServiceImpl implements LeaveService {
    private final LeaveRequestRepository repository;
    private final EmployeeRepository employeeRepository;
    private final LeaveMapper mapper;

    public LeaveServiceImpl(LeaveRequestRepository repository, EmployeeRepository employeeRepository, LeaveMapper mapper) {
        this.repository = repository;
        this.employeeRepository = employeeRepository;
        this.mapper = mapper;
    }

    public LeaveResponse request(LeaveRequestDto request) {
        if (request.endDate().isBefore(request.startDate())) {
            throw new BadRequestException("End date must be on or after start date");
        }
        return mapper.toResponse(repository.save(mapper.toEntity(request, employee(request.employeeId()))));
    }

    public LeaveResponse approve(Long id, LeaveApprovalRequest request) {
        LeaveRequest leaveRequest = active(id);
        leaveRequest.setStatus(Boolean.TRUE.equals(request.approved()) ? LeaveStatus.APPROVED : LeaveStatus.REJECTED);
        leaveRequest.setApproverComment(request.comment());
        return mapper.toResponse(leaveRequest);
    }

    @Transactional(readOnly = true)
    public LeaveResponse get(Long id) {
        return mapper.toResponse(active(id));
    }

    @Transactional(readOnly = true)
    public PagedResponse<LeaveResponse> list(int page, int size, String sortBy, String direction, Long employeeId) {
        var pageable = PageUtil.pageable(page, size, sortBy, direction);
        var result = employeeId == null ? repository.findByDeletedFalse(pageable) : repository.findByDeletedFalseAndEmployeeId(employeeId, pageable);
        return PagedResponse.from(result.map(mapper::toResponse));
    }

    public void delete(Long id) {
        active(id).setDeleted(true);
    }

    private LeaveRequest active(Long id) {
        LeaveRequest leaveRequest = repository.findById(id).orElseThrow(() -> new ResourceNotFoundException("Leave request not found"));
        if (leaveRequest.isDeleted()) {
            throw new ResourceNotFoundException("Leave request not found");
        }
        return leaveRequest;
    }

    private Employee employee(Long id) {
        Employee employee = employeeRepository.findById(id).orElseThrow(() -> new ResourceNotFoundException("Employee not found"));
        if (employee.isDeleted()) {
            throw new ResourceNotFoundException("Employee not found");
        }
        return employee;
    }
}
