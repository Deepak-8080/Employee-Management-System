package com.ems.service.impl;

import com.ems.dto.PagedResponse;
import com.ems.dto.SalaryRequest;
import com.ems.dto.SalaryResponse;
import com.ems.entity.Employee;
import com.ems.entity.Salary;
import com.ems.exception.ResourceNotFoundException;
import com.ems.mapper.SalaryMapper;
import com.ems.repository.EmployeeRepository;
import com.ems.repository.SalaryRepository;
import com.ems.service.SalaryService;
import com.ems.util.PageUtil;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Service
@Transactional
public class SalaryServiceImpl implements SalaryService {
    private final SalaryRepository repository;
    private final EmployeeRepository employeeRepository;
    private final SalaryMapper mapper;

    public SalaryServiceImpl(SalaryRepository repository, EmployeeRepository employeeRepository, SalaryMapper mapper) {
        this.repository = repository;
        this.employeeRepository = employeeRepository;
        this.mapper = mapper;
    }

    public SalaryResponse create(SalaryRequest request) {
        return mapper.toResponse(repository.save(mapper.toEntity(request, employee(request.employeeId()))));
    }

    public SalaryResponse update(Long id, SalaryRequest request) {
        Salary salary = active(id);
        mapper.update(salary, request, employee(request.employeeId()));
        return mapper.toResponse(salary);
    }

    @Transactional(readOnly = true)
    public SalaryResponse get(Long id) {
        return mapper.toResponse(active(id));
    }

    @Transactional(readOnly = true)
    public PagedResponse<SalaryResponse> list(int page, int size, String sortBy, String direction, Long employeeId) {
        var pageable = PageUtil.pageable(page, size, sortBy, direction);
        var result = employeeId == null ? repository.findByDeletedFalse(pageable) : repository.findByDeletedFalseAndEmployeeId(employeeId, pageable);
        return PagedResponse.from(result.map(mapper::toResponse));
    }

    public void delete(Long id) {
        active(id).setDeleted(true);
    }

    private Salary active(Long id) {
        Salary salary = repository.findById(id).orElseThrow(() -> new ResourceNotFoundException("Salary not found"));
        if (salary.isDeleted()) {
            throw new ResourceNotFoundException("Salary not found");
        }
        return salary;
    }

    private Employee employee(Long id) {
        Employee employee = employeeRepository.findById(id).orElseThrow(() -> new ResourceNotFoundException("Employee not found"));
        if (employee.isDeleted()) {
            throw new ResourceNotFoundException("Employee not found");
        }
        return employee;
    }
}
