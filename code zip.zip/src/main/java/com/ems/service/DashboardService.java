package com.ems.service;

import com.ems.dto.DashboardResponse;

public interface DashboardService {
    DashboardResponse dashboard();
}
