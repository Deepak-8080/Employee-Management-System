package com.ems.service;

import com.ems.dto.LeaveApprovalRequest;
import com.ems.dto.LeaveRequestDto;
import com.ems.dto.LeaveResponse;
import com.ems.dto.PagedResponse;

public interface LeaveService {
    LeaveResponse request(LeaveRequestDto request);
    LeaveResponse approve(Long id, LeaveApprovalRequest request);
    LeaveResponse get(Long id);
    PagedResponse<LeaveResponse> list(int page, int size, String sortBy, String direction, Long employeeId);
    void delete(Long id);
}
