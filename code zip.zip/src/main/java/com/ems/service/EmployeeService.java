package com.ems.service;

import com.ems.dto.EmployeeRequest;
import com.ems.dto.EmployeeResponse;
import com.ems.dto.PagedResponse;
import com.ems.enums.EmploymentStatus;
import org.springframework.web.multipart.MultipartFile;

public interface EmployeeService {
    EmployeeResponse create(EmployeeRequest request);
    EmployeeResponse update(Long id, EmployeeRequest request);
    EmployeeResponse get(Long id);
    PagedResponse<EmployeeResponse> list(int page, int size, String sortBy, String direction, Long departmentId, EmploymentStatus status);
    PagedResponse<EmployeeResponse> search(String keyword, int page, int size, String sortBy, String direction);
    EmployeeResponse uploadProfileImage(Long id, MultipartFile file);
    void delete(Long id);
}
