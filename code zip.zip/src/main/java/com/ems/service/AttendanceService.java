package com.ems.service;

import com.ems.dto.AttendanceRequest;
import com.ems.dto.AttendanceResponse;
import com.ems.dto.PagedResponse;

public interface AttendanceService {
    AttendanceResponse create(AttendanceRequest request);
    AttendanceResponse update(Long id, AttendanceRequest request);
    AttendanceResponse get(Long id);
    PagedResponse<AttendanceResponse> list(int page, int size, String sortBy, String direction, Long employeeId);
    void delete(Long id);
}
