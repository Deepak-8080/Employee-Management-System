package com.ems.service;

import com.ems.dto.DepartmentRequest;
import com.ems.dto.DepartmentResponse;
import com.ems.dto.PagedResponse;

public interface DepartmentService {
    DepartmentResponse create(DepartmentRequest request);
    DepartmentResponse update(Long id, DepartmentRequest request);
    DepartmentResponse get(Long id);
    PagedResponse<DepartmentResponse> list(int page, int size, String sortBy, String direction);
    void delete(Long id);
}
