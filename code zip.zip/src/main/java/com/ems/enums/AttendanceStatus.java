package com.ems.enums;

public enum AttendanceStatus {
    PRESENT,
    ABSENT,
    HALF_DAY,
    WORK_FROM_HOME
}
