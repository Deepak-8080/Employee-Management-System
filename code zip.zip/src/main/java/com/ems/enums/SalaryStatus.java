package com.ems.enums;

public enum SalaryStatus {
    PENDING,
    PAID,
    HOLD
}
