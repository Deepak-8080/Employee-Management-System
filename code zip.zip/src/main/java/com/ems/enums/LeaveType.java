package com.ems.enums;

public enum LeaveType {
    SICK,
    CASUAL,
    EARNED,
    UNPAID
}
