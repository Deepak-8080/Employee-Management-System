package com.ems.enums;

public enum EmploymentStatus {
    ACTIVE,
    INACTIVE,
    TERMINATED
}
