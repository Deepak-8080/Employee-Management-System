package com.ems.controller;

import com.ems.dto.ApiResponse;
import com.ems.dto.DashboardResponse;
import com.ems.service.DashboardService;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class DashboardController {
    private final DashboardService dashboardService;

    public DashboardController(DashboardService dashboardService) {
        this.dashboardService = dashboardService;
    }

    @GetMapping("/api/admin/dashboard")
    public ResponseEntity<ApiResponse<DashboardResponse>> adminDashboard() {
        return ResponseEntity.ok(ApiResponse.ok("Admin dashboard fetched", dashboardService.dashboard()));
    }

    @GetMapping("/api/hr/dashboard")
    public ResponseEntity<ApiResponse<DashboardResponse>> hrDashboard() {
        return ResponseEntity.ok(ApiResponse.ok("HR dashboard fetched", dashboardService.dashboard()));
    }

    @GetMapping("/api/employee/dashboard")
    public ResponseEntity<ApiResponse<DashboardResponse>> employeeDashboard() {
        return ResponseEntity.ok(ApiResponse.ok("Employee dashboard fetched", dashboardService.dashboard()));
    }
}
