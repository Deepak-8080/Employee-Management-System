package com.ems.controller;

import com.ems.dto.*;
import com.ems.service.SalaryService;
import jakarta.validation.Valid;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/salaries")
public class SalaryController {
    private final SalaryService service;

    public SalaryController(SalaryService service) {
        this.service = service;
    }

    @PostMapping
    public ResponseEntity<ApiResponse<SalaryResponse>> create(@Valid @RequestBody SalaryRequest request) {
        return ResponseEntity.status(HttpStatus.CREATED).body(ApiResponse.ok("Salary created", service.create(request)));
    }

    @PutMapping("/{id}")
    public ResponseEntity<ApiResponse<SalaryResponse>> update(@PathVariable Long id, @Valid @RequestBody SalaryRequest request) {
        return ResponseEntity.ok(ApiResponse.ok("Salary updated", service.update(id, request)));
    }

    @GetMapping("/{id}")
    public ResponseEntity<ApiResponse<SalaryResponse>> get(@PathVariable Long id) {
        return ResponseEntity.ok(ApiResponse.ok("Salary fetched", service.get(id)));
    }

    @GetMapping
    public ResponseEntity<ApiResponse<PagedResponse<SalaryResponse>>> list(@RequestParam(defaultValue = "0") int page, @RequestParam(defaultValue = "10") int size, @RequestParam(defaultValue = "id") String sortBy, @RequestParam(defaultValue = "asc") String direction, @RequestParam(required = false) Long employeeId) {
        return ResponseEntity.ok(ApiResponse.ok("Salaries fetched", service.list(page, size, sortBy, direction, employeeId)));
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<ApiResponse<Void>> delete(@PathVariable Long id) {
        service.delete(id);
        return ResponseEntity.ok(ApiResponse.ok("Salary deleted", null));
    }
}
