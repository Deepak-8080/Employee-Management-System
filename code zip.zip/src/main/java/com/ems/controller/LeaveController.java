package com.ems.controller;

import com.ems.dto.*;
import com.ems.service.LeaveService;
import jakarta.validation.Valid;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/leaves")
public class LeaveController {
    private final LeaveService service;

    public LeaveController(LeaveService service) {
        this.service = service;
    }

    @PostMapping
    public ResponseEntity<ApiResponse<LeaveResponse>> request(@Valid @RequestBody LeaveRequestDto request) {
        return ResponseEntity.status(HttpStatus.CREATED).body(ApiResponse.ok("Leave requested", service.request(request)));
    }

    @PatchMapping("/{id}/approval")
    public ResponseEntity<ApiResponse<LeaveResponse>> approve(@PathVariable Long id, @Valid @RequestBody LeaveApprovalRequest request) {
        return ResponseEntity.ok(ApiResponse.ok("Leave reviewed", service.approve(id, request)));
    }

    @GetMapping("/{id}")
    public ResponseEntity<ApiResponse<LeaveResponse>> get(@PathVariable Long id) {
        return ResponseEntity.ok(ApiResponse.ok("Leave fetched", service.get(id)));
    }

    @GetMapping
    public ResponseEntity<ApiResponse<PagedResponse<LeaveResponse>>> list(@RequestParam(defaultValue = "0") int page, @RequestParam(defaultValue = "10") int size, @RequestParam(defaultValue = "id") String sortBy, @RequestParam(defaultValue = "asc") String direction, @RequestParam(required = false) Long employeeId) {
        return ResponseEntity.ok(ApiResponse.ok("Leaves fetched", service.list(page, size, sortBy, direction, employeeId)));
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<ApiResponse<Void>> delete(@PathVariable Long id) {
        service.delete(id);
        return ResponseEntity.ok(ApiResponse.ok("Leave deleted", null));
    }
}
