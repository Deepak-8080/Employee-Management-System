package com.ems.dto;

import com.ems.enums.AttendanceStatus;
import jakarta.validation.constraints.NotNull;

import java.time.LocalDate;
import java.time.LocalTime;

public record AttendanceRequest(
        @NotNull Long employeeId,
        @NotNull LocalDate attendanceDate,
        LocalTime checkIn,
        LocalTime checkOut,
        @NotNull AttendanceStatus status
) {
}
