package com.ems.dto;

import com.ems.enums.SalaryStatus;
import jakarta.validation.constraints.DecimalMin;
import jakarta.validation.constraints.NotNull;

import java.math.BigDecimal;
import java.time.LocalDate;

public record SalaryRequest(
        @NotNull Long employeeId,
        @NotNull LocalDate salaryMonth,
        @NotNull @DecimalMin("0.00") BigDecimal basicPay,
        @NotNull @DecimalMin("0.00") BigDecimal allowances,
        @NotNull @DecimalMin("0.00") BigDecimal deductions,
        @NotNull SalaryStatus status
) {
}
