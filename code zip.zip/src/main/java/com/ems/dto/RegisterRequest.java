package com.ems.dto;

import jakarta.validation.constraints.Email;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Pattern;
import jakarta.validation.constraints.Size;

import java.util.Set;

public record RegisterRequest(
        @NotBlank @Size(min = 3, max = 80) String username,
        @NotBlank @Email String email,
        @NotBlank @Size(min = 8, max = 80) @Pattern(regexp = "^(?=.*[A-Z])(?=.*[a-z])(?=.*\\d).+$") String password,
        Set<String> roles
) {
}
