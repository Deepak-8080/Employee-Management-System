package com.ems.dto;

public record DepartmentResponse(
        Long id,
        String name,
        String description
) {
}
