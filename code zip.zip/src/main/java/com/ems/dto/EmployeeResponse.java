package com.ems.dto;

import com.ems.enums.EmploymentStatus;

import java.time.LocalDate;

public record EmployeeResponse(
        Long id,
        String employeeCode,
        String firstName,
        String lastName,
        String email,
        String phone,
        String designation,
        LocalDate dateOfJoining,
        EmploymentStatus status,
        String address,
        String profileImagePath,
        DepartmentResponse department,
        Long userId
) {
}
