package com.ems.dto;

import com.ems.enums.LeaveStatus;
import com.ems.enums.LeaveType;

import java.time.LocalDate;

public record LeaveResponse(
        Long id,
        Long employeeId,
        String employeeName,
        LeaveType type,
        LocalDate startDate,
        LocalDate endDate,
        String reason,
        LeaveStatus status,
        String approverComment
) {
}
