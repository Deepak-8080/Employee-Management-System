package com.ems.dto;

import com.ems.enums.SalaryStatus;

import java.math.BigDecimal;
import java.time.LocalDate;

public record SalaryResponse(
        Long id,
        Long employeeId,
        String employeeName,
        LocalDate salaryMonth,
        BigDecimal basicPay,
        BigDecimal allowances,
        BigDecimal deductions,
        BigDecimal netPay,
        SalaryStatus status
) {
}
