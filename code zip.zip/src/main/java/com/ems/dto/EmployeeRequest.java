package com.ems.dto;

import com.ems.enums.EmploymentStatus;
import jakarta.validation.constraints.*;

import java.time.LocalDate;

public record EmployeeRequest(
        @NotBlank @Size(max = 40) String employeeCode,
        @NotBlank @Size(max = 80) String firstName,
        @NotBlank @Size(max = 80) String lastName,
        @NotBlank @Email String email,
        @NotBlank @Pattern(regexp = "^[0-9+\\- ]{8,20}$") String phone,
        @Size(max = 120) String designation,
        @NotNull LocalDate dateOfJoining,
        @NotNull EmploymentStatus status,
        @Size(max = 500) String address,
        @NotNull Long departmentId,
        Long userId
) {
}
