package com.ems.dto;

public record DashboardResponse(
        long totalEmployees,
        long totalDepartments,
        long pendingLeaves,
        long todayAttendance,
        long paidSalaries
) {
}
