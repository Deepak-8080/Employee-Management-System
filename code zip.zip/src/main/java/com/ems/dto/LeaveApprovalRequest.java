package com.ems.dto;

import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;

public record LeaveApprovalRequest(
        @NotNull Boolean approved,
        @Size(max = 500) String comment
) {
}
