package com.ems.repository;

import com.ems.entity.Employee;
import com.ems.enums.EmploymentStatus;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;

public interface EmployeeRepository extends JpaRepository<Employee, Long> {
    Page<Employee> findByDeletedFalse(Pageable pageable);
    Page<Employee> findByDeletedFalseAndDepartmentId(Long departmentId, Pageable pageable);
    Page<Employee> findByDeletedFalseAndStatus(EmploymentStatus status, Pageable pageable);
    Page<Employee> findByDeletedFalseAndFirstNameContainingIgnoreCaseOrDeletedFalseAndLastNameContainingIgnoreCaseOrDeletedFalseAndEmailContainingIgnoreCase(String firstName, String lastName, String email, Pageable pageable);
    boolean existsByEmployeeCodeAndDeletedFalse(String employeeCode);
    boolean existsByEmailAndDeletedFalse(String email);
}
