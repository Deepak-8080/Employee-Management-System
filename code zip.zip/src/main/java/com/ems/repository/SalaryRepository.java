package com.ems.repository;

import com.ems.entity.Salary;
import com.ems.enums.SalaryStatus;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;

public interface SalaryRepository extends JpaRepository<Salary, Long> {
    Page<Salary> findByDeletedFalse(Pageable pageable);
    Page<Salary> findByDeletedFalseAndEmployeeId(Long employeeId, Pageable pageable);
    long countByDeletedFalseAndStatus(SalaryStatus status);
}
