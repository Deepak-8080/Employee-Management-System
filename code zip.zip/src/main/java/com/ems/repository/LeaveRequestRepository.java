package com.ems.repository;

import com.ems.entity.LeaveRequest;
import com.ems.enums.LeaveStatus;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;

public interface LeaveRequestRepository extends JpaRepository<LeaveRequest, Long> {
    Page<LeaveRequest> findByDeletedFalse(Pageable pageable);
    Page<LeaveRequest> findByDeletedFalseAndEmployeeId(Long employeeId, Pageable pageable);
    long countByDeletedFalseAndStatus(LeaveStatus status);
}
