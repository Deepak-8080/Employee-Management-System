package com.ems.repository;

import com.ems.entity.Attendance;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;

import java.time.LocalDate;

public interface AttendanceRepository extends JpaRepository<Attendance, Long> {
    Page<Attendance> findByDeletedFalse(Pageable pageable);
    Page<Attendance> findByDeletedFalseAndEmployeeId(Long employeeId, Pageable pageable);
    long countByDeletedFalseAndAttendanceDate(LocalDate attendanceDate);
}
