package com.ems.mapper;

import com.ems.dto.AttendanceRequest;
import com.ems.dto.AttendanceResponse;
import com.ems.entity.Attendance;
import com.ems.entity.Employee;
import org.springframework.stereotype.Component;

@Component
public class AttendanceMapper {
    public Attendance toEntity(AttendanceRequest request, Employee employee) {
        return Attendance.builder().employee(employee).attendanceDate(request.attendanceDate()).checkIn(request.checkIn()).checkOut(request.checkOut()).status(request.status()).build();
    }

    public void update(Attendance attendance, AttendanceRequest request, Employee employee) {
        attendance.setEmployee(employee);
        attendance.setAttendanceDate(request.attendanceDate());
        attendance.setCheckIn(request.checkIn());
        attendance.setCheckOut(request.checkOut());
        attendance.setStatus(request.status());
    }

    public AttendanceResponse toResponse(Attendance attendance) {
        Employee employee = attendance.getEmployee();
        return new AttendanceResponse(attendance.getId(), employee.getId(), employee.getFirstName() + " " + employee.getLastName(), attendance.getAttendanceDate(), attendance.getCheckIn(), attendance.getCheckOut(), attendance.getStatus());
    }
}
