package com.ems.mapper;

import com.ems.dto.SalaryRequest;
import com.ems.dto.SalaryResponse;
import com.ems.entity.Employee;
import com.ems.entity.Salary;
import org.springframework.stereotype.Component;

import java.math.BigDecimal;

@Component
public class SalaryMapper {
    public Salary toEntity(SalaryRequest request, Employee employee) {
        return Salary.builder().employee(employee).salaryMonth(request.salaryMonth()).basicPay(request.basicPay()).allowances(request.allowances()).deductions(request.deductions()).netPay(net(request)).status(request.status()).build();
    }

    public void update(Salary salary, SalaryRequest request, Employee employee) {
        salary.setEmployee(employee);
        salary.setSalaryMonth(request.salaryMonth());
        salary.setBasicPay(request.basicPay());
        salary.setAllowances(request.allowances());
        salary.setDeductions(request.deductions());
        salary.setNetPay(net(request));
        salary.setStatus(request.status());
    }

    public SalaryResponse toResponse(Salary salary) {
        Employee employee = salary.getEmployee();
        return new SalaryResponse(salary.getId(), employee.getId(), employee.getFirstName() + " " + employee.getLastName(), salary.getSalaryMonth(), salary.getBasicPay(), salary.getAllowances(), salary.getDeductions(), salary.getNetPay(), salary.getStatus());
    }

    private BigDecimal net(SalaryRequest request) {
        return request.basicPay().add(request.allowances()).subtract(request.deductions());
    }
}
