package com.ems.mapper;

import com.ems.dto.LeaveRequestDto;
import com.ems.dto.LeaveResponse;
import com.ems.entity.Employee;
import com.ems.entity.LeaveRequest;
import com.ems.enums.LeaveStatus;
import org.springframework.stereotype.Component;

@Component
public class LeaveMapper {
    public LeaveRequest toEntity(LeaveRequestDto request, Employee employee) {
        return LeaveRequest.builder().employee(employee).type(request.type()).startDate(request.startDate()).endDate(request.endDate()).reason(request.reason()).status(LeaveStatus.PENDING).build();
    }

    public LeaveResponse toResponse(LeaveRequest leaveRequest) {
        Employee employee = leaveRequest.getEmployee();
        return new LeaveResponse(leaveRequest.getId(), employee.getId(), employee.getFirstName() + " " + employee.getLastName(), leaveRequest.getType(), leaveRequest.getStartDate(), leaveRequest.getEndDate(), leaveRequest.getReason(), leaveRequest.getStatus(), leaveRequest.getApproverComment());
    }
}
