package com.ems.mapper;

import com.ems.dto.EmployeeRequest;
import com.ems.dto.EmployeeResponse;
import com.ems.entity.Department;
import com.ems.entity.Employee;
import com.ems.entity.User;
import org.springframework.stereotype.Component;

@Component
public class EmployeeMapper {
    private final DepartmentMapper departmentMapper;

    public EmployeeMapper(DepartmentMapper departmentMapper) {
        this.departmentMapper = departmentMapper;
    }

    public Employee toEntity(EmployeeRequest request, Department department, User user) {
        return Employee.builder()
                .employeeCode(request.employeeCode())
                .firstName(request.firstName())
                .lastName(request.lastName())
                .email(request.email())
                .phone(request.phone())
                .designation(request.designation())
                .dateOfJoining(request.dateOfJoining())
                .status(request.status())
                .address(request.address())
                .department(department)
                .user(user)
                .build();
    }

    public void update(Employee employee, EmployeeRequest request, Department department, User user) {
        employee.setEmployeeCode(request.employeeCode());
        employee.setFirstName(request.firstName());
        employee.setLastName(request.lastName());
        employee.setEmail(request.email());
        employee.setPhone(request.phone());
        employee.setDesignation(request.designation());
        employee.setDateOfJoining(request.dateOfJoining());
        employee.setStatus(request.status());
        employee.setAddress(request.address());
        employee.setDepartment(department);
        employee.setUser(user);
    }

    public EmployeeResponse toResponse(Employee employee) {
        Long userId = employee.getUser() == null ? null : employee.getUser().getId();
        return new EmployeeResponse(employee.getId(), employee.getEmployeeCode(), employee.getFirstName(), employee.getLastName(), employee.getEmail(), employee.getPhone(), employee.getDesignation(), employee.getDateOfJoining(), employee.getStatus(), employee.getAddress(), employee.getProfileImagePath(), departmentMapper.toResponse(employee.getDepartment()), userId);
    }
}
