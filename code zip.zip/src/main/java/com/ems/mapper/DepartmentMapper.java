package com.ems.mapper;

import com.ems.dto.DepartmentRequest;
import com.ems.dto.DepartmentResponse;
import com.ems.entity.Department;
import org.springframework.stereotype.Component;

@Component
public class DepartmentMapper {
    public Department toEntity(DepartmentRequest request) {
        return Department.builder().name(request.name()).description(request.description()).build();
    }

    public void update(Department department, DepartmentRequest request) {
        department.setName(request.name());
        department.setDescription(request.description());
    }

    public DepartmentResponse toResponse(Department department) {
        return new DepartmentResponse(department.getId(), department.getName(), department.getDescription());
    }
}
