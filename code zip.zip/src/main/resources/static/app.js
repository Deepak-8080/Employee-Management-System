const state = {
    token: localStorage.getItem("emsToken"),
    user: JSON.parse(localStorage.getItem("emsUser") || "null")
};

const loginView = document.getElementById("loginView");
const appView = document.getElementById("appView");
const pageTitle = document.getElementById("pageTitle");

function authHeaders() {
    return {
        "Content-Type": "application/json",
        "Authorization": `Bearer ${state.token}`
    };
}

async function api(path, options = {}) {
    const response = await fetch(path, {
        ...options,
        headers: {
            ...(options.headers || {}),
            ...(state.token ? authHeaders() : {"Content-Type": "application/json"})
        }
    });
    const body = await response.json().catch(() => null);
    if (!response.ok) {
        throw new Error(body?.message || "Request failed");
    }
    return body?.data;
}

function showApp() {
    loginView.classList.add("hidden");
    appView.classList.remove("hidden");
    document.getElementById("userName").textContent = state.user?.username || "User";
    document.getElementById("userRoles").textContent = Array.from(state.user?.roles || []).join(", ");
    loadDashboard();
}

function showLogin() {
    appView.classList.add("hidden");
    loginView.classList.remove("hidden");
}

document.getElementById("loginForm").addEventListener("submit", async event => {
    event.preventDefault();
    document.getElementById("loginError").textContent = "";
    try {
        const data = await api("/api/auth/login", {
            method: "POST",
            body: JSON.stringify({
                usernameOrEmail: document.getElementById("usernameOrEmail").value,
                password: document.getElementById("password").value
            })
        });
        state.token = data.accessToken;
        state.user = data;
        localStorage.setItem("emsToken", state.token);
        localStorage.setItem("emsUser", JSON.stringify(state.user));
        showApp();
    } catch (error) {
        document.getElementById("loginError").textContent = error.message;
    }
});

document.getElementById("logoutBtn").addEventListener("click", () => {
    localStorage.removeItem("emsToken");
    localStorage.removeItem("emsUser");
    state.token = null;
    state.user = null;
    showLogin();
});

document.querySelectorAll(".nav-item").forEach(button => {
    button.addEventListener("click", () => {
        document.querySelectorAll(".nav-item").forEach(item => item.classList.remove("active"));
        button.classList.add("active");
        document.querySelectorAll(".view").forEach(view => view.classList.add("hidden"));
        document.getElementById(button.dataset.view).classList.remove("hidden");
        pageTitle.textContent = button.textContent;
        loaders[button.dataset.view]();
    });
});

const loaders = {
    dashboard: loadDashboard,
    employees: loadEmployees,
    departments: loadDepartments,
    attendance: loadAttendance,
    leaves: loadLeaves,
    salaries: loadSalaries
};

async function loadDashboard() {
    const data = await api("/api/admin/dashboard");
    document.getElementById("totalEmployees").textContent = data.totalEmployees;
    document.getElementById("totalDepartments").textContent = data.totalDepartments;
    document.getElementById("pendingLeaves").textContent = data.pendingLeaves;
    document.getElementById("todayAttendance").textContent = data.todayAttendance;
    document.getElementById("paidSalaries").textContent = data.paidSalaries;
}

async function loadEmployees(keyword = "") {
    const path = keyword ? `/api/employees/search?keyword=${encodeURIComponent(keyword)}` : "/api/employees";
    const data = await api(path);
    rows("employeesTable", data.content, item => `
        <tr>
            <td>${item.employeeCode}</td>
            <td>${item.firstName} ${item.lastName}</td>
            <td>${item.email}</td>
            <td>${item.department?.name || ""}</td>
            <td>${item.status}</td>
        </tr>
    `);
}

async function loadDepartments() {
    const data = await api("/api/departments");
    rows("departmentsTable", data.content, item => `
        <tr>
            <td>${item.name}</td>
            <td>${item.description || ""}</td>
        </tr>
    `);
}

async function loadAttendance() {
    const data = await api("/api/attendance");
    rows("attendanceTable", data.content, item => `
        <tr>
            <td>${item.employeeName}</td>
            <td>${item.attendanceDate}</td>
            <td>${item.checkIn || ""}</td>
            <td>${item.checkOut || ""}</td>
            <td>${item.status}</td>
        </tr>
    `);
}

async function loadLeaves() {
    const data = await api("/api/leaves");
    rows("leavesTable", data.content, item => `
        <tr>
            <td>${item.employeeName}</td>
            <td>${item.type}</td>
            <td>${item.startDate} to ${item.endDate}</td>
            <td>${item.reason}</td>
            <td>${item.status}</td>
        </tr>
    `);
}

async function loadSalaries() {
    const data = await api("/api/salaries");
    rows("salariesTable", data.content, item => `
        <tr>
            <td>${item.employeeName}</td>
            <td>${item.salaryMonth}</td>
            <td>${money(item.basicPay)}</td>
            <td>${money(item.netPay)}</td>
            <td>${item.status}</td>
        </tr>
    `);
}

function rows(id, items, template) {
    document.getElementById(id).innerHTML = items.length ? items.map(template).join("") : `<tr><td colspan="6">No records found</td></tr>`;
}

function money(value) {
    return Number(value).toLocaleString("en-IN", {style: "currency", currency: "INR"});
}

document.getElementById("employeeSearchBtn").addEventListener("click", () => {
    loadEmployees(document.getElementById("employeeSearch").value);
});

document.getElementById("departmentForm").addEventListener("submit", async event => {
    event.preventDefault();
    await api("/api/departments", {
        method: "POST",
        body: JSON.stringify({
            name: document.getElementById("departmentName").value,
            description: document.getElementById("departmentDescription").value
        })
    });
    event.target.reset();
    loadDepartments();
    loadDashboard();
});

if (state.token) {
    showApp();
} else {
    showLogin();
}
