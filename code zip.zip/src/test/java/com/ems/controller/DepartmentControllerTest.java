package com.ems.controller;

import com.ems.dto.DepartmentRequest;
import com.ems.dto.DepartmentResponse;
import com.ems.service.DepartmentService;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.junit.jupiter.api.Test;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;

import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

class DepartmentControllerTest {
    @Test
    void createReturnsCreated() throws Exception {
        DepartmentService service = mock(DepartmentService.class);
        MockMvc mockMvc = MockMvcBuilders.standaloneSetup(new DepartmentController(service)).build();
        DepartmentRequest request = new DepartmentRequest("Engineering", "Software");
        when(service.create(request)).thenReturn(new DepartmentResponse(1L, "Engineering", "Software"));
        mockMvc.perform(post("/api/departments").contentType(MediaType.APPLICATION_JSON).content(new ObjectMapper().writeValueAsString(request)))
                .andExpect(status().isCreated())
                .andExpect(jsonPath("$.success").value(true))
                .andExpect(jsonPath("$.data.name").value("Engineering"));
    }
}
