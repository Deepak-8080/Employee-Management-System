package com.ems.service;

import com.ems.dto.LeaveRequestDto;
import com.ems.enums.LeaveType;
import com.ems.exception.BadRequestException;
import com.ems.mapper.LeaveMapper;
import com.ems.repository.EmployeeRepository;
import com.ems.repository.LeaveRequestRepository;
import com.ems.service.impl.LeaveServiceImpl;
import org.junit.jupiter.api.Test;

import java.time.LocalDate;

import static org.assertj.core.api.Assertions.assertThatThrownBy;
import static org.mockito.Mockito.mock;

class LeaveServiceImplTest {
    @Test
    void requestRejectsInvalidDateRange() {
        LeaveServiceImpl service = new LeaveServiceImpl(mock(LeaveRequestRepository.class), mock(EmployeeRepository.class), new LeaveMapper());
        LeaveRequestDto request = new LeaveRequestDto(1L, LeaveType.CASUAL, LocalDate.now().plusDays(2), LocalDate.now(), "Personal");
        assertThatThrownBy(() -> service.request(request)).isInstanceOf(BadRequestException.class);
    }
}
