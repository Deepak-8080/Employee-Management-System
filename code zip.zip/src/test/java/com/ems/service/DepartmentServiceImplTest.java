package com.ems.service;

import com.ems.dto.DepartmentRequest;
import com.ems.entity.Department;
import com.ems.mapper.DepartmentMapper;
import com.ems.repository.DepartmentRepository;
import com.ems.service.impl.DepartmentServiceImpl;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
class DepartmentServiceImplTest {
    @Mock
    private DepartmentRepository repository;

    private final DepartmentMapper mapper = new DepartmentMapper();

    @Test
    void createReturnsDepartmentResponse() {
        DepartmentServiceImpl service = new DepartmentServiceImpl(repository, mapper);
        Department saved = Department.builder().id(1L).name("Engineering").description("Software").build();
        when(repository.existsByNameIgnoreCaseAndDeletedFalse("Engineering")).thenReturn(false);
        when(repository.save(any(Department.class))).thenReturn(saved);
        var response = service.create(new DepartmentRequest("Engineering", "Software"));
        assertThat(response.id()).isEqualTo(1L);
        assertThat(response.name()).isEqualTo("Engineering");
    }
}
